"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { Container, Card, Title, Subtitle, Button, Input, PageFade } from "@/components/ui";
import { Clock3, BookOpen, HeartHandshake, PencilLine, CheckCircle2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";

function todayISO() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function clampInt(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, Math.floor(n)));
}

function toMinutes(hStr: string, mStr: string) {
  const h = hStr.trim() === "" ? 0 : clampInt(Number(hStr), 0, 24);
  const m = mStr.trim() === "" ? 0 : clampInt(Number(mStr), 0, 59);
  return h * 60 + m;
}

function fromMinutes(total: number) {
  const t = Number.isFinite(total) ? Math.max(0, Math.floor(total)) : 0;
  return { h: Math.floor(t / 60), m: t % 60 };
}

function traducirError(msg: string) {
  const m = (msg ?? "").toLowerCase();

  if (m.includes("jwt") || m.includes("token")) return "Tu sesión expiró. Vuelve a iniciar sesión.";
  if (m.includes("row-level security") || m.includes("rls") || m.includes("security policy"))
    return "No tienes permisos para guardar/editar el reporte (políticas de seguridad).";
  if (m.includes("permission denied") || m.includes("not allowed"))
    return "No tienes permisos para realizar esta acción.";
  if (m.includes("duplicate key") || m.includes("unique"))
    return "Ya existe un reporte para esa fecha.";
  if (m.includes("check constraint") || m.includes("violates check constraint"))
    return "Los datos no cumplen una validación del sistema. Revisa los valores e intenta de nuevo.";
  if (m.includes("not-null") || m.includes("null value") || m.includes("cannot be null"))
    return "Falta un campo requerido. Revisa los valores e intenta de nuevo.";
  if (m.includes("does not exist") && m.includes("column"))
    return "Tu base de datos no tiene el campo actualizado. Avísame para ajustar compatibilidad.";
  if (m.includes("stack depth"))
    return "Error de seguridad/roles. Recarga la página (si continúa, avísame).";

  return "Ocurrió un error. Intenta de nuevo.";
}


type ExistingReport = {
  prayer_minutes: number;
  chapters_count?: number | null;
  bible_minutes?: number | null; // legacy (capítulos)
};

type Mode = "loading" | "new" | "askEdit" | "editing" | "done" | "doneLocked";

function lockKey(dateISO: string) {
  return `report_lock_${dateISO}`;
}

function notifyLockChanged() {
  try {
    window.dispatchEvent(new Event("report_lock_changed"));
  } catch { }
}

export default function ReportePage() {
  const today = useMemo(() => todayISO(), []);
  const dateKey = today;

  const [mode, setMode] = useState<Mode>("loading");
  const [existing, setExisting] = useState<ExistingReport | null>(null);

  // UX: por defecto mostramos 0 (limpio)
  const [prayerH, setPrayerH] = useState<string>("");
  const [prayerM, setPrayerM] = useState<string>("");

  // Campos (ahora requeridos)
  const [chaptersCount, setChaptersCount] = useState<string>("");

  const [msg, setMsg] = useState("");

  const { loading, session } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!session) router.replace("/");
  }, [loading, session, router]);

  useEffect(() => {
    if (loading || !session) return;

    // aquí ya es estable
    const loadReport = async () => {
      try {
        const { data, error } = await supabase
          .from("reports")
          .select("chapters_count, bible_minutes, prayer_minutes")
          .eq("user_id", session.user.id)
          .eq("report_date", dateKey)
          .maybeSingle();

        if (error) {
          console.error("Error loading report:", error);
          setMode("new");
          return;
        }

        if (data) {
          const chapters = (data as any).chapters_count ?? (data as any).bible_minutes ?? 0;
          setExisting({ ...(data as any), chapters_count: chapters });
          setMode("askEdit");
        } else {
          setMode("new");
        }
      } catch (err) {
        console.error("Error loading report:", err);
        setMode("new");
      }
    };

    loadReport();
  }, [loading, session, dateKey]);



  const onlyDigits = (v: string) => v.replace(/[^\d]/g, "");

  function loadExistingIntoForm() {
    const p = fromMinutes(existing?.prayer_minutes ?? 0);

    // UX: si el valor es 0, mostramos el input vacío (se ve más limpio que un "0" fijo)
    setPrayerH(p.h === 0 ? "" : String(p.h));
    setPrayerM(p.m === 0 ? "" : String(p.m));

    // Capítulos (requerido)
    const cc = (existing?.chapters_count ?? existing?.bible_minutes ?? 0);
    setChaptersCount(!Number.isFinite(Number(cc)) ? "" : String(cc));
  }

  async function save() {
    setMsg("");

    const { data: sess } = await supabase.auth.getSession();
    const user = sess.session?.user;
    if (!user) return;

    const prayer_minutes = toMinutes(prayerH, prayerM);

    if (chaptersCount.trim() === "") {
      setMsg("Ingresa la cantidad de capítulos leídos.");
      return;
    }

    const chapters_count = clampInt(Number(chaptersCount), 0, 500);

    const { error } = await supabase.from("reports").upsert(
      {
        user_id: user.id,
        report_date: today,
        // Compatibilidad con vistas/estadísticas existentes en Supabase:
        // reaprovechamos bible_minutes como "capítulos".
        bible_minutes: chapters_count,
        prayer_minutes,
        chapters_count,
      },
      { onConflict: "user_id,report_date" }
    );

    if (error) {
      console.error("Error saving report:", error);
      const friendly = traducirError(error.message);
      // Si el mensaje es muy genérico, mostramos un hint pequeño para debug.
      const hint = error.message ? ` (${error.message})` : "";
      setMsg(friendly + hint);
      return;
    }

    setExisting({ prayer_minutes, chapters_count });
    try {
      localStorage.removeItem(lockKey(dateKey));
    } catch { }
    notifyLockChanged();
    setMode("done");
    setMsg("✅ Guardado correctamente");
  }

  const Summary = ({ allowEdit }: { allowEdit: boolean }) => {
    const p = fromMinutes(existing?.prayer_minutes ?? 0);

    return (
      <div className="grid gap-3">
        <div className="flex items-center gap-2 text-emerald-200/90">
          <CheckCircle2 size={18} />
          <div className="font-semibold">Ya reportaste hoy</div>
        </div>

        <div className="grid gap-2 text-sm text-white/70">
          <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-4 py-3">
            <span className="flex items-center gap-2">
              <HeartHandshake size={16} className="opacity-80" /> Oración
            </span>
            <span className="font-semibold text-white">
              {p.h}h {p.m}m
            </span>
          </div>

          {(() => {
            const chapters = (existing?.chapters_count ?? existing?.bible_minutes ?? 0);
            return (
              <div className="rounded-xl border border-white/10 bg-black/20 px-4 py-3">
                <div className="grid gap-2">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-white/70">Capítulos leídos</span>
                    <span className="font-semibold text-white">{chapters}</span>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>

        {allowEdit ? (
          <>
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <Button
                variant="ghost"
                onClick={() => {
                  try {
                    localStorage.removeItem(lockKey(dateKey));
                  } catch { }
                  notifyLockChanged();
                  loadExistingIntoForm();
                  setMode("editing");
                  setMsg("");
                }}
              >
                <PencilLine size={16} />
                Editar reporte
              </Button>
            </div>

            <div className="text-xs text-white/50">
              Si quieres, puedes editarlo durante el día. (Siempre se guarda <b>solo</b> para la fecha de hoy.)
            </div>
          </>
        ) : (
          <div className="text-xs text-white/50">
            Ya reportaste hoy. (Elegiste no editar.)
          </div>
        )}
      </div>
    );
  };

  return (
    <Container>
      <PageFade>
        <div className="grid gap-6">
          <div>
            <Title>Mi reporte</Title>
            <Subtitle>Registra tu cantidad de capítulos leídos y tu tiempo de oración (en horas y minutos).</Subtitle>
          </div>

          <Card>
            {mode === "loading" ? (
              <div className="text-sm text-white/70">Cargando…</div>
            ) : mode === "askEdit" ? (
              <div className="grid gap-4">
                <div className="text-sm text-white/80">
                  Ya existe un reporte para hoy. ¿Quieres <b>editarlo</b>?
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <Button
                    onClick={() => {
                      try {
                        localStorage.removeItem(lockKey(dateKey));
                      } catch { }
                      notifyLockChanged();
                      loadExistingIntoForm();
                      setMode("editing");
                    }}
                  >
                    <PencilLine size={16} />
                    Sí, editar
                  </Button>

                  <Button
                    variant="ghost"
                    onClick={() => {
                      // Si elige no editar, guardamos un "lock" (solo hoy) para
                      // que la app no muestre la opción de reporte/editar otra vez.
                      try {
                        localStorage.setItem(lockKey(dateKey), "1");
                      } catch { }
                      notifyLockChanged();
                      setMode("doneLocked");
                      setMsg("");
                    }}
                  >
                    No, gracias
                  </Button>
                </div>

                <div className="text-xs text-white/50">
                  Nota: si eliges “No, gracias”, la opción de <b>Reporte</b> se oculta por hoy.
                </div>
              </div>
            ) : mode === "done" ? (
              <Summary allowEdit />
            ) : mode === "doneLocked" ? (
              <Summary allowEdit={false} />
            ) : (
              // new | editing
              <div className="grid gap-5">
                <div className="flex items-center gap-2 text-sm text-white/70">
                  <Clock3 size={16} />
                  <span>Fecha</span>
                </div>

                <Input type="date" value={today} disabled className="max-w-xs opacity-70 cursor-not-allowed" />

                <div className="text-xs text-white/50">
                  Solo puedes reportar el día de hoy. (La base de datos también lo valida.)
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                    <div className="flex items-center gap-2 font-medium">
                      <BookOpen size={18} className="opacity-80" />
                      Capítulos leídos
                    </div>

                    <div className="mt-3">
                      <div className="text-xs text-white/60 mb-1">Cantidad</div>
                      <Input
                        inputMode="numeric"
                        placeholder="0"
                        value={chaptersCount}
                        onChange={(e) => setChaptersCount(onlyDigits(e.target.value))}
                        onBlur={() => {
                          if (chaptersCount.trim() === "") return;
                          const n = clampInt(Number(chaptersCount), 0, 500);
                          setChaptersCount(String(n));
                        }}
                      />
                    </div>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                    <div className="flex items-center gap-2 font-medium">
                      <HeartHandshake size={18} className="opacity-80" />
                      Tiempo de oración
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-3">
                      <div>
                        <div className="text-xs text-white/60 mb-1">Horas</div>
                        <Input
                          inputMode="numeric"
                          placeholder="0"
                          value={prayerH}
                          onFocus={(e) => {
                            if (prayerH === "0") setPrayerH("");
                            try {
                              (e.target as HTMLInputElement).select();
                            } catch { }
                          }}
                          onChange={(e) => setPrayerH(onlyDigits(e.target.value))}
                          onBlur={() => {
                            if (prayerH.trim() === "") return;
                            const n = clampInt(Number(prayerH), 0, 24);
                            setPrayerH(String(n));
                          }}
                        />
                      </div>
                      <div>
                        <div className="text-xs text-white/60 mb-1">Minutos</div>
                        <Input
                          inputMode="numeric"
                          placeholder="0"
                          value={prayerM}
                          onFocus={(e) => {
                            if (prayerM === "0") setPrayerM("");
                            try {
                              (e.target as HTMLInputElement).select();
                            } catch { }
                          }}
                          onChange={(e) => setPrayerM(onlyDigits(e.target.value))}
                          onBlur={() => {
                            if (prayerM.trim() === "") return;
                            const n = clampInt(Number(prayerM), 0, 59);
                            setPrayerM(String(n));
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <Button onClick={save}>{mode === "editing" ? "Guardar cambios" : "Guardar"}</Button>

                  {mode === "editing" && (
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setMode("done");
                        setMsg("");
                      }}
                    >
                      Cancelar
                    </Button>
                  )}

                  {msg && (
                    <span className={msg.startsWith("✅") ? "text-green-300 text-sm" : "text-red-300 text-sm"}>
                      {msg}
                    </span>
                  )}
                </div>

                <div className="text-xs text-white/50">
                  Tip: si borras un campo, se guarda como 0. (Capítulos es requerido.)
                </div>
              </div>
            )}
          </Card>
        </div>
      </PageFade>
    </Container>
  );
}
